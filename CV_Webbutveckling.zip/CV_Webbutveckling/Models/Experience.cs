﻿namespace CV_Webbutveckling.Models
{
    public class Experience
    {
        public int Id { get; set; }

        public string ExpPlace { get; set; }

        public string ExpType { get; set; }

        public string ExpDuration { get; set; }

        public Experience()
        {

        }
    }
}
