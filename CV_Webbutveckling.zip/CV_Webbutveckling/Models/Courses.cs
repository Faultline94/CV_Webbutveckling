﻿namespace CV_Webbutveckling.Models
{
    public class Courses
    {
        public int Id { get; set; }

        public string CoursePlace { get; set; }
        public string Course { get; set;}
        
        public string CourseType { get; set; }

        public string CourseDuration { get; set; }

        public Courses()
        {

        }
    }
}
